<?php
// check email availability logic here
?>